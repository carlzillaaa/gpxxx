florb is a really simple map viewer and GPX editor written in C++ using the
FLTK UI toolkit. See http://florb.shugaa.de for details.

florb is distributed under the terms of the MIT license as can be found in
LICENSE.txt.
